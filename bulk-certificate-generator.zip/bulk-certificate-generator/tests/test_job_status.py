"""Job status and progress, and the per-certificate listing."""

from sqlalchemy import select

from app.models import Job
from app.services import processor
from app.services.processor import count_by_status


def test_status_of_finished_job(submit):
    _, status = submit()

    assert status["status"] == "completed"
    assert status["total"] == 3
    assert status["progress_percent"] == 100.0
    assert status["started_at"] is not None
    assert status["finished_at"] is not None
    assert status["download_url"] == f"/jobs/{status['id']}/download"


def test_status_reports_live_progress_while_processing(client, make_payload, session_factory, monkeypatch):
    snapshots = []
    real_generate = processor.generate_certificate_pdf

    def spy(*args, **kwargs):
        # Look at the job from a separate DB session, as a polling client would.
        with session_factory() as db:
            job = db.scalars(select(Job)).one()
            counts = count_by_status(db, job.id)
            snapshots.append((job.status, counts["generated"], counts["pending"]))
        return real_generate(*args, **kwargs)

    monkeypatch.setattr(processor, "generate_certificate_pdf", spy)

    job_id = client.post("/jobs", json=make_payload()).json()["id"]

    assert snapshots == [("processing", 0, 3), ("processing", 1, 2), ("processing", 2, 1)]
    assert client.get(f"/jobs/{job_id}").json()["status"] == "completed"


def test_progress_percent_counts_generated_and_failed(client, make_job_in_db):
    job_id = make_job_in_db("processing", ["generated", "failed", "pending", "pending"])

    body = client.get(f"/jobs/{job_id}").json()

    assert body["status"] == "processing"
    assert (body["generated"], body["failed"], body["pending"]) == (1, 1, 2)
    assert body["progress_percent"] == 50.0
    assert body["finished_at"] is None
    assert body["download_url"] is None  # not available until the job has finished


def test_unknown_job_returns_404(client):
    assert client.get("/jobs/does-not-exist").status_code == 404
    assert client.get("/jobs/does-not-exist/certificates").status_code == 404


def test_certificate_listing_shows_every_recipient(client, submit):
    job_id, _ = submit()

    body = client.get(f"/jobs/{job_id}/certificates").json()

    assert body["total"] == 3
    assert [i["recipient_name"] for i in body["items"]] == ["Alice Johnson", "Bob Smith", "Carol White"]
    assert [i["index"] for i in body["items"]] == [0, 1, 2]
    assert all(i["status"] == "generated" for i in body["items"])
    assert all(i["download_url"] for i in body["items"])


def test_certificate_listing_can_filter_by_status(client, submit):
    payload = {"event_name": "E", "recipients": [{"name": "Good One"}, {"name": ""}, {"name": "Good Two"}]}
    job_id, _ = submit(payload)

    generated = client.get(f"/jobs/{job_id}/certificates", params={"status": "generated"}).json()
    failed = client.get(f"/jobs/{job_id}/certificates", params={"status": "failed"}).json()

    assert generated["total"] == 2 and failed["total"] == 1
    assert failed["items"][0]["download_url"] is None


def test_certificate_listing_is_paginated(client, submit, make_payload):
    names = [f"Person Number{i}" for i in range(10)]
    job_id, _ = submit(make_payload(names=names))

    page = client.get(f"/jobs/{job_id}/certificates", params={"limit": 4, "offset": 8}).json()

    assert page["total"] == 10
    assert (page["limit"], page["offset"]) == (4, 8)
    assert [i["index"] for i in page["items"]] == [8, 9]


def test_certificate_listing_rejects_bad_query_parameters(client, submit):
    job_id, _ = submit()
    base = f"/jobs/{job_id}/certificates"

    assert client.get(base, params={"status": "nonsense"}).status_code == 422
    assert client.get(base, params={"limit": 0}).status_code == 422
    assert client.get(base, params={"offset": -1}).status_code == 422


def test_health_endpoint(client):
    assert client.get("/health").json() == {"status": "ok"}
