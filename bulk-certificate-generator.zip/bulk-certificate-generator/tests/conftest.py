"""Shared fixtures.

Every test gets its own temporary SQLite database and certificate folder, so
tests are isolated and never touch real data. FastAPI's TestClient runs
background tasks before returning from a request, so after ``client.post``
the job is already processed and can be inspected deterministically.
"""

from datetime import date

import pytest
from fastapi.testclient import TestClient
from sqlalchemy.orm import sessionmaker

from app.config import Settings, get_settings
from app.database import Base, make_engine
from app.dependencies import get_session_factory
from app.main import app
from app.models import Certificate, Job


@pytest.fixture
def settings(tmp_path):
    return Settings(
        database_url=f"sqlite:///{tmp_path / 'test.db'}",
        cert_dir=tmp_path / "certs",
        max_recipients=50,
    )


@pytest.fixture
def session_factory(settings):
    engine = make_engine(settings.database_url)
    Base.metadata.create_all(engine)
    factory = sessionmaker(bind=engine, expire_on_commit=False)
    yield factory
    engine.dispose()


@pytest.fixture
def client(settings, session_factory):
    app.dependency_overrides[get_settings] = lambda: settings
    app.dependency_overrides[get_session_factory] = lambda: session_factory
    yield TestClient(app)
    app.dependency_overrides.clear()


@pytest.fixture
def make_payload():
    def _make(names=("Alice Johnson", "Bob Smith", "Carol White"), **overrides):
        payload = {
            "event_name": "Python Bootcamp 2026",
            "issued_by": "Aereo Academy",
            "recipients": [
                {"name": n, "email": f"{n.split()[0].lower()}@example.com"} for n in names
            ],
        }
        payload.update(overrides)
        return payload

    return _make


@pytest.fixture
def submit(client, make_payload):
    """POST a job and return (job_id, final job status JSON)."""

    def _submit(payload=None):
        r = client.post("/jobs", json=payload or make_payload())
        assert r.status_code == 202, r.text
        job_id = r.json()["id"]
        return job_id, client.get(f"/jobs/{job_id}").json()

    return _submit


@pytest.fixture
def make_job_in_db(session_factory):
    """Insert a job directly in a chosen state (to test states that are
    otherwise only visible for a split second while processing)."""

    def _make(status, cert_statuses):
        with session_factory() as db:
            job = Job(
                status=status,
                event_name="Seeded Event",
                issue_date=date(2026, 1, 1),
                total=len(cert_statuses),
            )
            for i, cert_status in enumerate(cert_statuses):
                job.certificates.append(
                    Certificate(
                        index=i,
                        recipient_name=f"Person {i}",
                        status=cert_status,
                        error="seeded error" if cert_status == "failed" else None,
                        file_path="does-not-exist.pdf" if cert_status == "generated" else None,
                    )
                )
            db.add(job)
            db.commit()
            return job.id

    return _make
