"""Creating a generation job."""

from datetime import date

from sqlalchemy import func, select

from app.models import Job


def test_create_job_returns_202_with_job_details(client, make_payload):
    response = client.post("/jobs", json=make_payload())

    assert response.status_code == 202
    body = response.json()
    assert body["id"]
    assert body["total"] == 3
    assert body["event_name"] == "Python Bootcamp 2026"
    assert body["issued_by"] == "Aereo Academy"
    # The response is sent before background processing starts.
    assert body["status"] == "pending"
    assert body["pending"] == 3
    assert body["certificates_url"] == f"/jobs/{body['id']}/certificates"


def test_job_is_processed_in_the_background(submit, settings):
    job_id, status = submit()

    assert status["status"] == "completed"
    assert status["generated"] == 3
    assert status["failed"] == 0
    assert status["pending"] == 0
    assert status["progress_percent"] == 100.0
    assert len(list((settings.cert_dir / job_id).glob("*.pdf"))) == 3


def test_bulk_request_with_many_recipients_is_one_call(submit, make_payload):
    names = [f"Person Number{i}" for i in range(40)]
    _, status = submit(make_payload(names=names))

    assert status["total"] == 40
    assert status["generated"] == 40
    assert status["status"] == "completed"


def test_issue_date_defaults_to_today(submit):
    _, status = submit()
    assert status["issue_date"] == date.today().isoformat()


def test_custom_issue_date_is_used(submit, make_payload):
    _, status = submit(make_payload(issue_date="2026-03-15"))
    assert status["issue_date"] == "2026-03-15"


def test_issued_by_is_optional(submit, make_payload):
    payload = make_payload()
    del payload["issued_by"]
    _, status = submit(payload)
    assert status["status"] == "completed"
    assert status["issued_by"] is None


def test_each_job_gets_its_own_id(client, make_payload):
    first = client.post("/jobs", json=make_payload()).json()["id"]
    second = client.post("/jobs", json=make_payload()).json()["id"]
    assert first != second


def test_unknown_extra_fields_are_ignored(submit, make_payload):
    payload = make_payload()
    payload["recipients"][0]["favourite_colour"] = "blue"
    _, status = submit(payload)
    assert status["status"] == "completed"


def test_recipient_name_is_trimmed(client, submit, make_payload):
    job_id, _ = submit(make_payload(names=("  Alice Johnson  ",)))
    items = client.get(f"/jobs/{job_id}/certificates").json()["items"]
    assert items[0]["recipient_name"] == "Alice Johnson"


def test_jobs_are_persisted_in_the_database(client, make_payload, session_factory):
    client.post("/jobs", json=make_payload())
    with session_factory() as db:
        assert db.scalar(select(func.count()).select_from(Job)) == 1
