"""A failure in one certificate must not stop the others."""

import pytest

from app.services import processor


@pytest.fixture
def fail_for(monkeypatch):
    """Make the generator raise for the given recipient names only."""

    def _install(*names):
        real_generate = processor.generate_certificate_pdf

        def flaky(path, *, recipient_name, **kwargs):
            if recipient_name in names:
                raise RuntimeError(f"cannot render {recipient_name}")
            return real_generate(path, recipient_name=recipient_name, **kwargs)

        monkeypatch.setattr(processor, "generate_certificate_pdf", flaky)

    return _install


def test_one_failing_certificate_does_not_block_the_others(client, submit, fail_for, settings):
    fail_for("Bob Smith")

    job_id, status = submit()

    assert status["status"] == "completed_with_errors"
    assert (status["generated"], status["failed"], status["pending"]) == (2, 1, 0)
    assert status["progress_percent"] == 100.0
    assert len(list((settings.cert_dir / job_id).glob("*.pdf"))) == 2


def test_failed_certificate_reports_its_error(client, submit, fail_for):
    fail_for("Bob Smith")
    job_id, _ = submit()

    items = client.get(f"/jobs/{job_id}/certificates").json()["items"]
    by_name = {i["recipient_name"]: i for i in items}

    assert by_name["Alice Johnson"]["status"] == "generated"
    assert by_name["Carol White"]["status"] == "generated"
    bob = by_name["Bob Smith"]
    assert bob["status"] == "failed"
    assert bob["index"] == 1
    assert "RuntimeError" in bob["error"] and "cannot render Bob Smith" in bob["error"]
    assert bob["download_url"] is None


def test_failure_in_the_first_certificate_still_processes_the_rest(submit, fail_for):
    fail_for("Alice Johnson")
    _, status = submit()
    assert (status["generated"], status["failed"]) == (2, 1)


def test_failed_certificate_cannot_be_downloaded(client, submit, fail_for):
    fail_for("Bob Smith")
    job_id, _ = submit()
    failed = client.get(f"/jobs/{job_id}/certificates", params={"status": "failed"}).json()["items"][0]

    response = client.get(f"/jobs/{job_id}/certificates/{failed['id']}/download")

    assert response.status_code == 409
    assert "failed" in response.json()["detail"]


def test_job_where_every_certificate_fails_is_marked_failed(client, submit, fail_for):
    fail_for("Alice Johnson", "Bob Smith", "Carol White")

    _, status = submit()

    assert status["status"] == "failed"
    assert (status["generated"], status["failed"]) == (0, 3)
    assert status["download_url"] is None


def test_validation_failures_and_generation_failures_are_reported_together(client, submit, fail_for):
    fail_for("Bob Smith")
    payload = {
        "event_name": "E",
        "recipients": [{"name": "Alice Johnson"}, {"name": "Bob Smith"}, {"name": ""}],
    }
    job_id, status = submit(payload)

    assert (status["generated"], status["failed"]) == (1, 2)
    failed = client.get(f"/jobs/{job_id}/certificates", params={"status": "failed"}).json()
    assert [i["index"] for i in failed["items"]] == [1, 2]


def test_unexpected_processor_error_does_not_leave_job_stuck(client, make_payload, monkeypatch):
    """Infrastructure-level failure (not one bad certificate): the job must still finish."""

    def explode(*args, **kwargs):
        raise ConnectionError("database went away")

    monkeypatch.setattr(processor, "_generate_one", explode)

    job_id = client.post("/jobs", json=make_payload()).json()["id"]
    status = client.get(f"/jobs/{job_id}").json()

    assert status["status"] == "failed"
    assert status["pending"] == 0
    assert status["finished_at"] is not None
    items = client.get(f"/jobs/{job_id}/certificates").json()["items"]
    assert all("Job aborted" in i["error"] for i in items)
