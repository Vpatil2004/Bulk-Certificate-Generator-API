"""Input validation: request-level (422) and per-recipient (recorded as failed)."""

import pytest
from sqlalchemy import func, select

from app.models import Job
from app.services.validation import validate_recipient


# --------------------------------------------------------------------------
# Request level: the whole request is rejected
# --------------------------------------------------------------------------
@pytest.mark.parametrize(
    "mutation",
    [
        pytest.param(lambda p: p.update(recipients=[]), id="empty-recipients"),
        pytest.param(lambda p: p.pop("recipients"), id="missing-recipients"),
        pytest.param(lambda p: p.update(recipients="Alice"), id="recipients-not-a-list"),
        pytest.param(lambda p: p.pop("event_name"), id="missing-event-name"),
        pytest.param(lambda p: p.update(event_name="   "), id="blank-event-name"),
        pytest.param(lambda p: p.update(event_name="E" * 121), id="event-name-too-long"),
        pytest.param(lambda p: p.update(issue_date="not-a-date"), id="invalid-date"),
        pytest.param(lambda p: p.update(issued_by=""), id="blank-issuer"),
    ],
)
def test_invalid_request_is_rejected_with_422(client, make_payload, session_factory, mutation):
    payload = make_payload()
    mutation(payload)

    response = client.post("/jobs", json=payload)

    assert response.status_code == 422
    with session_factory() as db:  # nothing was stored
        assert db.scalar(select(func.count()).select_from(Job)) == 0


def test_too_many_recipients_is_rejected(client, make_payload, settings, session_factory):
    names = [f"Person Number{i}" for i in range(settings.max_recipients + 1)]

    response = client.post("/jobs", json=make_payload(names=names))

    assert response.status_code == 422
    assert "Too many recipients" in response.json()["detail"]
    with session_factory() as db:
        assert db.scalar(select(func.count()).select_from(Job)) == 0


def test_exactly_the_maximum_number_of_recipients_is_accepted(submit, make_payload, settings):
    names = [f"Person Number{i}" for i in range(settings.max_recipients)]
    _, status = submit(make_payload(names=names))
    assert status["generated"] == settings.max_recipients


# --------------------------------------------------------------------------
# Recipient level: only that recipient fails
# --------------------------------------------------------------------------
@pytest.mark.parametrize(
    "bad_recipient, expected_error",
    [
        pytest.param({"email": "x@example.com"}, "name is required", id="missing-name"),
        pytest.param({"name": "   "}, "must not be blank", id="blank-name"),
        pytest.param({"name": 12345}, "must be a string", id="non-string-name"),
        pytest.param({"name": "X" * 81}, "at most 80", id="name-too-long"),
        pytest.param({"name": "Bad\nName"}, "control characters", id="control-characters"),
        pytest.param({"name": "प्रिया पाटील"}, "cannot render", id="unsupported-script"),
        pytest.param({"name": "Dan", "email": "not-an-email"}, "valid email", id="bad-email"),
        pytest.param({"name": "Dan", "email": 42}, "email must be a string", id="non-string-email"),
    ],
)
def test_invalid_recipient_fails_alone_and_others_succeed(
    client, submit, bad_recipient, expected_error
):
    payload = {
        "event_name": "Python Bootcamp 2026",
        "recipients": [
            {"name": "Alice Johnson", "email": "alice@example.com"},
            bad_recipient,
            {"name": "Carol White"},
        ],
    }

    job_id, status = submit(payload)

    assert status["status"] == "completed_with_errors"
    assert (status["generated"], status["failed"], status["pending"]) == (2, 1, 0)

    failed = client.get(f"/jobs/{job_id}/certificates", params={"status": "failed"}).json()
    assert failed["total"] == 1
    assert failed["items"][0]["index"] == 1  # maps back to the submitted row
    assert expected_error in failed["items"][0]["error"]


def test_multiple_problems_on_one_recipient_are_all_reported(client, submit):
    payload = {
        "event_name": "Event",
        "recipients": [{"name": "", "email": "nope"}, {"name": "Valid Person"}],
    }
    job_id, _ = submit(payload)

    failed = client.get(f"/jobs/{job_id}/certificates", params={"status": "failed"}).json()
    error = failed["items"][0]["error"]
    assert "name must not be blank" in error and "valid email" in error


def test_email_is_optional(submit):
    payload = {
        "event_name": "Event",
        "recipients": [{"name": "No Email"}, {"name": "Empty Email", "email": ""}],
    }
    _, status = submit(payload)
    assert status["status"] == "completed"


def test_job_where_every_recipient_is_invalid_finishes_as_failed(client, submit):
    payload = {"event_name": "Event", "recipients": [{}, {"name": ""}]}

    job_id, status = submit(payload)

    assert status["status"] == "failed"
    assert (status["generated"], status["failed"]) == (0, 2)
    assert status["finished_at"] is not None
    assert status["download_url"] is None
    assert client.get(f"/jobs/{job_id}/download").status_code == 404


def test_validate_recipient_accepts_accented_latin_names():
    result = validate_recipient("Zoë Müller", "zoe@example.com")
    assert result.error is None
    assert result.name == "Zoë Müller"


def test_validate_recipient_never_raises_on_odd_input():
    for name in (None, 1, 1.5, [], {}, True):
        assert validate_recipient(name, None).error
