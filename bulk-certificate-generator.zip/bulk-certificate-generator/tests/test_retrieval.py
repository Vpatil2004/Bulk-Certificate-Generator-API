"""Retrieving generated certificates (single PDF and ZIP)."""

import io
import zipfile


def test_download_single_certificate(client, submit):
    job_id, _ = submit()
    cert = client.get(f"/jobs/{job_id}/certificates").json()["items"][0]

    response = client.get(cert["download_url"])

    assert response.status_code == 200
    assert response.headers["content-type"] == "application/pdf"
    assert response.content.startswith(b"%PDF")
    assert "certificate-alice-johnson" in response.headers["content-disposition"]


def test_each_certificate_downloads_its_own_file(client, submit):
    job_id, _ = submit()
    items = client.get(f"/jobs/{job_id}/certificates").json()["items"]

    contents = {client.get(i["download_url"]).content for i in items}

    assert len(contents) == 3  # three distinct PDFs


def test_download_unknown_certificate_returns_404(client, submit):
    job_id, _ = submit()
    assert client.get(f"/jobs/{job_id}/certificates/999999/download").status_code == 404


def test_download_from_unknown_job_returns_404(client):
    assert client.get("/jobs/nope/certificates/1/download").status_code == 404
    assert client.get("/jobs/nope/download").status_code == 404


def test_certificate_cannot_be_fetched_through_another_job(client, submit):
    job_a, _ = submit()
    job_b, _ = submit()
    cert_of_a = client.get(f"/jobs/{job_a}/certificates").json()["items"][0]

    response = client.get(f"/jobs/{job_b}/certificates/{cert_of_a['id']}/download")

    assert response.status_code == 404


def test_download_with_non_numeric_certificate_id_returns_422(client, submit):
    job_id, _ = submit()
    assert client.get(f"/jobs/{job_id}/certificates/abc/download").status_code == 422


def test_missing_file_on_disk_returns_404(client, make_job_in_db):
    job_id = make_job_in_db("completed", ["generated"])
    cert = client.get(f"/jobs/{job_id}/certificates").json()["items"][0]

    response = client.get(cert["download_url"])

    assert response.status_code == 404
    assert "missing" in response.json()["detail"]


def test_zip_contains_every_generated_certificate(client, submit):
    job_id, status = submit()

    response = client.get(status["download_url"])

    assert response.status_code == 200
    assert response.headers["content-type"] == "application/zip"
    assert f"certificates-{job_id[:8]}.zip" in response.headers["content-disposition"]
    with zipfile.ZipFile(io.BytesIO(response.content)) as archive:
        assert archive.namelist() == [
            "0001-alice-johnson.pdf",
            "0002-bob-smith.pdf",
            "0003-carol-white.pdf",
        ]
        assert all(archive.read(name).startswith(b"%PDF") for name in archive.namelist())


def test_zip_only_contains_successful_certificates(client, submit):
    payload = {"event_name": "E", "recipients": [{"name": "Good One"}, {"name": ""}, {"name": "Good Two"}]}
    _, status = submit(payload)

    response = client.get(status["download_url"])

    with zipfile.ZipFile(io.BytesIO(response.content)) as archive:
        assert archive.namelist() == ["0001-good-one.pdf", "0003-good-two.pdf"]


def test_accented_names_get_readable_file_names(client, submit):
    payload = {"event_name": "E", "recipients": [{"name": "Zoë Müller"}]}
    _, status = submit(payload)

    with zipfile.ZipFile(io.BytesIO(client.get(status["download_url"]).content)) as archive:
        assert archive.namelist() == ["0001-zoe-muller.pdf"]


def test_zip_keeps_recipients_with_identical_names_apart(client, submit):
    payload = {"event_name": "E", "recipients": [{"name": "Sam Lee"}, {"name": "Sam Lee"}]}
    _, status = submit(payload)

    with zipfile.ZipFile(io.BytesIO(client.get(status["download_url"]).content)) as archive:
        assert len(set(archive.namelist())) == 2


def test_zip_is_refused_while_job_is_still_running(client, make_job_in_db):
    job_id = make_job_in_db("processing", ["generated", "pending"])

    response = client.get(f"/jobs/{job_id}/download")

    assert response.status_code == 409
    assert "processing" in response.json()["detail"]


def test_zip_is_refused_for_job_that_has_not_started(client, make_job_in_db):
    job_id = make_job_in_db("pending", ["pending"])
    assert client.get(f"/jobs/{job_id}/download").status_code == 409
