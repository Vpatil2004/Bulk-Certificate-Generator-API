"""Certificate generation (the PDF template itself)."""

from datetime import date

import pytest
from reportlab import rl_config
from reportlab.pdfgen import canvas

from app.services.generator import generate_certificate_pdf


def render(path, **overrides):
    kwargs = dict(
        recipient_name="Priya Sharma",
        event_name="Python Bootcamp 2026",
        issued_by="Aereo Academy",
        issue_date=date(2026, 10, 9),
        certificate_id="ABCD1234-000001",
    )
    kwargs.update(overrides)
    generate_certificate_pdf(path, **kwargs)


def test_generates_a_valid_pdf_file(tmp_path):
    out = tmp_path / "cert.pdf"
    render(out)

    data = out.read_bytes()
    assert data.startswith(b"%PDF")
    assert b"%%EOF" in data[-32:]


def test_certificate_contains_recipient_specific_information(tmp_path, monkeypatch):
    # Turn off stream compression so the text can be found in the raw bytes.
    monkeypatch.setattr(rl_config, "pageCompression", 0)
    out = tmp_path / "cert.pdf"

    render(out, recipient_name="Priya Sharma", event_name="Data Science 101")

    content = out.read_bytes()
    assert b"(Priya Sharma)" in content
    assert b"(Data Science 101)" in content
    assert b"9 October 2026" in content
    assert b"Aereo Academy" in content
    assert b"ABCD1234-000001" in content


def test_different_recipients_produce_different_files(tmp_path, monkeypatch):
    monkeypatch.setattr(rl_config, "pageCompression", 0)
    render(tmp_path / "a.pdf", recipient_name="Alice Johnson")
    render(tmp_path / "b.pdf", recipient_name="Bob Smith")

    assert b"(Alice Johnson)" in (tmp_path / "a.pdf").read_bytes()
    assert b"(Alice Johnson)" not in (tmp_path / "b.pdf").read_bytes()


def test_creates_missing_parent_folders(tmp_path):
    out = tmp_path / "job-1" / "nested" / "cert.pdf"
    render(out)
    assert out.is_file()


def test_issuer_line_is_optional(tmp_path, monkeypatch):
    monkeypatch.setattr(rl_config, "pageCompression", 0)
    out = tmp_path / "cert.pdf"
    render(out, issued_by=None)
    assert b"Issued by" not in out.read_bytes()


def test_longest_allowed_name_and_event_still_render(tmp_path):
    out = tmp_path / "cert.pdf"
    render(out, recipient_name="W" * 80, event_name="E" * 120, issued_by="I" * 80)
    assert out.read_bytes().startswith(b"%PDF")


def test_markup_like_text_is_rendered_literally(tmp_path, monkeypatch):
    monkeypatch.setattr(rl_config, "pageCompression", 0)
    out = tmp_path / "cert.pdf"
    render(out, recipient_name="<b>Tom</b> & Jerry")
    assert b"<b>Tom</b> & Jerry" in out.read_bytes()


def test_no_temp_file_is_left_after_success(tmp_path):
    render(tmp_path / "cert.pdf")
    assert [p.name for p in tmp_path.iterdir()] == ["cert.pdf"]


def test_failure_leaves_no_partial_file_behind(tmp_path, monkeypatch):
    def broken_save(self):
        raise OSError("disk full")

    monkeypatch.setattr(canvas.Canvas, "save", broken_save)
    out = tmp_path / "cert.pdf"

    with pytest.raises(OSError, match="disk full"):
        render(out)

    assert list(tmp_path.iterdir()) == []
