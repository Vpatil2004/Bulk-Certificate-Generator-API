"""Application settings, read from environment variables with sensible defaults."""

import os
from dataclasses import dataclass
from functools import lru_cache
from pathlib import Path


@dataclass(frozen=True)
class Settings:
    # Any SQLAlchemy URL works (e.g. postgresql+psycopg://user:pass@host/db).
    database_url: str = "sqlite:///./certificates.db"
    # Folder where generated PDFs are stored (one sub-folder per job).
    cert_dir: Path = Path("./generated_certificates")
    # Upper bound on recipients per request, to protect the server.
    max_recipients: int = 1000


@lru_cache
def get_settings() -> Settings:
    return Settings(
        database_url=os.getenv("DATABASE_URL", Settings.database_url),
        cert_dir=Path(os.getenv("CERT_DIR", str(Settings.cert_dir))),
        max_recipients=int(os.getenv("MAX_RECIPIENTS", Settings.max_recipients)),
    )
