"""FastAPI dependencies. Tests override these to use a temporary DB and folder."""

from collections.abc import Iterator

from fastapi import Depends
from sqlalchemy.orm import Session, sessionmaker

from app.database import SessionLocal


def get_session_factory() -> sessionmaker:
    return SessionLocal


def get_db(factory: sessionmaker = Depends(get_session_factory)) -> Iterator[Session]:
    with factory() as db:
        yield db
