"""ORM models: a Job groups many Certificates created from one request."""

import uuid
from datetime import date, datetime, timezone
from typing import Optional

from sqlalchemy import Date, DateTime, ForeignKey, Integer, String, Text, UniqueConstraint
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.database import Base


def utcnow() -> datetime:
    """Naive UTC timestamp (SQLite does not keep time zones anyway)."""
    return datetime.now(timezone.utc).replace(tzinfo=None)


class JobStatus:
    PENDING = "pending"  # accepted, waiting for the processor
    PROCESSING = "processing"  # certificates are being generated
    COMPLETED = "completed"  # every certificate generated
    COMPLETED_WITH_ERRORS = "completed_with_errors"  # some generated, some failed
    FAILED = "failed"  # nothing could be generated

    FINISHED = (COMPLETED, COMPLETED_WITH_ERRORS, FAILED)


class CertificateStatus:
    PENDING = "pending"
    GENERATED = "generated"
    FAILED = "failed"


class Job(Base):
    __tablename__ = "jobs"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    status: Mapped[str] = mapped_column(String(32), default=JobStatus.PENDING, index=True)
    event_name: Mapped[str] = mapped_column(String(200))
    issued_by: Mapped[Optional[str]] = mapped_column(String(200), nullable=True)
    issue_date: Mapped[date] = mapped_column(Date)
    total: Mapped[int] = mapped_column(Integer)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)
    started_at: Mapped[Optional[datetime]] = mapped_column(DateTime, nullable=True)
    finished_at: Mapped[Optional[datetime]] = mapped_column(DateTime, nullable=True)

    certificates: Mapped[list["Certificate"]] = relationship(
        back_populates="job", cascade="all, delete-orphan", order_by="Certificate.index"
    )


class Certificate(Base):
    __tablename__ = "certificates"
    __table_args__ = (UniqueConstraint("job_id", "index", name="uq_certificate_job_index"),)

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    job_id: Mapped[str] = mapped_column(ForeignKey("jobs.id", ondelete="CASCADE"), index=True)
    # Position of the recipient in the original request (0-based) so that
    # clients can map an error back to the row they submitted.
    index: Mapped[int] = mapped_column(Integer)
    recipient_name: Mapped[str] = mapped_column(String(255), default="")
    recipient_email: Mapped[Optional[str]] = mapped_column(String(320), nullable=True)
    status: Mapped[str] = mapped_column(String(16), default=CertificateStatus.PENDING, index=True)
    error: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    # Path relative to the configured certificate directory.
    file_path: Mapped[Optional[str]] = mapped_column(String(512), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)
    generated_at: Mapped[Optional[datetime]] = mapped_column(DateTime, nullable=True)

    job: Mapped[Job] = relationship(back_populates="certificates")
