"""Application entry point: ``uvicorn app.main:app``."""

from contextlib import asynccontextmanager

from fastapi import FastAPI

from app import models  # noqa: F401  (registers the tables on Base.metadata)
from app.config import get_settings
from app.database import Base, engine
from app.routers import jobs


@asynccontextmanager
async def lifespan(_app: FastAPI):
    Base.metadata.create_all(engine)
    get_settings().cert_dir.mkdir(parents=True, exist_ok=True)
    yield


app = FastAPI(
    title="Bulk Certificate Generator API",
    version="1.0.0",
    description=(
        "Submit many recipients in one request, track the generation job, "
        "and download the generated PDF certificates."
    ),
    lifespan=lifespan,
)
app.include_router(jobs.router)


@app.get("/health", tags=["meta"])
def health():
    return {"status": "ok"}
