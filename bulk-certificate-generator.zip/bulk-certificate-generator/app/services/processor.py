"""Background processing of a certificate job.

Design notes
------------
* Each certificate is generated inside its own try/except and committed
  immediately. A failure is recorded on that one row; the loop carries on.
  Committing per certificate also means status polling shows live progress.
* The job's final status is derived from the certificate rows (the single
  source of truth), never from in-memory counters.
"""

import logging
from pathlib import Path

from sqlalchemy import func, select, update
from sqlalchemy.orm import Session, sessionmaker

from app.models import Certificate, CertificateStatus, Job, JobStatus, utcnow
from app.services.generator import generate_certificate_pdf

logger = logging.getLogger(__name__)

MAX_ERROR_LENGTH = 500


def count_by_status(db: Session, job_id: str) -> dict[str, int]:
    rows = db.execute(
        select(Certificate.status, func.count())
        .where(Certificate.job_id == job_id)
        .group_by(Certificate.status)
    ).all()
    counts = {CertificateStatus.PENDING: 0, CertificateStatus.GENERATED: 0, CertificateStatus.FAILED: 0}
    counts.update({status: n for status, n in rows})
    return counts


def final_status(counts: dict[str, int]) -> str:
    generated = counts[CertificateStatus.GENERATED]
    total = sum(counts.values())
    if generated == total:
        return JobStatus.COMPLETED
    if generated == 0:
        return JobStatus.FAILED
    return JobStatus.COMPLETED_WITH_ERRORS


def finalize_job(db: Session, job: Job) -> None:
    job.status = final_status(count_by_status(db, job.id))
    job.finished_at = utcnow()
    db.commit()


def _generate_one(db: Session, job: Job, cert: Certificate, cert_dir: Path) -> None:
    relative_path = f"{job.id}/{cert.id}.pdf"
    try:
        generate_certificate_pdf(
            cert_dir / relative_path,
            recipient_name=cert.recipient_name,
            event_name=job.event_name,
            issued_by=job.issued_by,
            issue_date=job.issue_date,
            certificate_id=f"{job.id[:8].upper()}-{cert.id:06d}",
        )
    except Exception as exc:  # one bad certificate must not stop the job
        logger.warning("Certificate %s (job %s) failed: %s", cert.id, job.id, exc)
        cert.status = CertificateStatus.FAILED
        cert.error = f"{type(exc).__name__}: {exc}"[:MAX_ERROR_LENGTH]
    else:
        cert.status = CertificateStatus.GENERATED
        cert.file_path = relative_path
        cert.generated_at = utcnow()
    db.commit()


def process_job(job_id: str, session_factory: sessionmaker, cert_dir: Path) -> None:
    """Generate every pending certificate of a job. Runs in a background thread."""
    with session_factory() as db:
        job = db.get(Job, job_id)
        if job is None:
            logger.error("process_job: job %s not found", job_id)
            return

        job.status = JobStatus.PROCESSING
        job.started_at = utcnow()
        db.commit()

        try:
            pending_ids = db.scalars(
                select(Certificate.id)
                .where(Certificate.job_id == job_id, Certificate.status == CertificateStatus.PENDING)
                .order_by(Certificate.index)
            ).all()
            for cert_id in pending_ids:
                _generate_one(db, job, db.get(Certificate, cert_id), cert_dir)
        except Exception as exc:
            # Infrastructure-level problem (e.g. database error), not a single
            # bad certificate. Make sure the job does not stay "processing".
            logger.exception("Job %s aborted", job_id)
            db.rollback()
            db.execute(
                update(Certificate)
                .where(Certificate.job_id == job_id, Certificate.status == CertificateStatus.PENDING)
                .values(
                    status=CertificateStatus.FAILED,
                    error=f"Job aborted: {type(exc).__name__}: {exc}"[:MAX_ERROR_LENGTH],
                )
            )
            db.commit()
        finally:
            finalize_job(db, db.get(Job, job_id))
