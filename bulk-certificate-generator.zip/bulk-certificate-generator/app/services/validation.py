"""Per-recipient validation.

Request-level problems (no recipients, missing event name, ...) are rejected by
the schema with HTTP 422. Problems with an individual recipient are different:
they must not block the other recipients, so they are recorded as a failed
certificate with a readable error message instead.
"""

import re
import unicodedata
from dataclasses import dataclass
from typing import Any, Optional

MAX_NAME_LENGTH = 80
MAX_EMAIL_LENGTH = 254
_EMAIL_RE = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")


@dataclass
class ValidatedRecipient:
    name: str  # cleaned name if valid, otherwise a best-effort echo of the input
    email: Optional[str]
    error: Optional[str]  # None when the recipient is valid


def _has_control_chars(value: str) -> bool:
    return any(unicodedata.category(ch).startswith("C") for ch in value)


def _is_renderable(value: str) -> bool:
    """The template uses ReportLab's built-in Helvetica (WinAnsi / cp1252).

    Characters outside that set would silently render as blanks, so they are
    rejected up front with a clear message instead of producing a bad PDF.
    To support other scripts, register a Unicode TTF font in generator.py and
    remove this check.
    """
    try:
        value.encode("cp1252")
    except UnicodeEncodeError:
        return False
    return True


def validate_recipient(raw_name: Any, raw_email: Any) -> ValidatedRecipient:
    errors: list[str] = []

    # --- name -------------------------------------------------------------
    name = ""
    if raw_name is None:
        errors.append("name is required")
    elif not isinstance(raw_name, str):
        errors.append("name must be a string")
        name = str(raw_name)[:255]
    else:
        name = raw_name.strip()
        if not name:
            errors.append("name must not be blank")
        elif len(name) > MAX_NAME_LENGTH:
            errors.append(f"name must be at most {MAX_NAME_LENGTH} characters")
            name = name[:255]
        elif _has_control_chars(name):
            errors.append("name contains control characters")
        elif not _is_renderable(name):
            errors.append(
                "name contains characters the certificate font cannot render "
                "(only Latin letters, including accents, are supported)"
            )

    # --- email (optional) ---------------------------------------------------
    email: Optional[str] = None
    if raw_email is not None and raw_email != "":
        if not isinstance(raw_email, str):
            errors.append("email must be a string")
        else:
            candidate = raw_email.strip()
            if len(candidate) > MAX_EMAIL_LENGTH or not _EMAIL_RE.match(candidate):
                errors.append("email is not a valid email address")
                email = candidate[:320]
            else:
                email = candidate

    return ValidatedRecipient(name=name, email=email, error="; ".join(errors) or None)
