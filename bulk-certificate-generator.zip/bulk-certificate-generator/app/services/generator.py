"""PDF generation using the single predefined certificate template.

The template is drawn directly with ReportLab's canvas (no Paragraph markup),
so recipient-supplied text can never be interpreted as markup.
"""

import os
from datetime import date
from pathlib import Path

from reportlab.lib.colors import HexColor
from reportlab.lib.pagesizes import A4, landscape
from reportlab.pdfbase.pdfmetrics import stringWidth
from reportlab.pdfgen import canvas

PAGE_WIDTH, PAGE_HEIGHT = landscape(A4)
NAVY = HexColor("#1f2a44")
GOLD = HexColor("#b8923a")
GREY = HexColor("#5a6275")
MAX_TEXT_WIDTH = PAGE_WIDTH - 160  # keep text clear of the border


def _fit_font_size(text: str, font: str, size: float, min_size: float = 9) -> float:
    """Shrink the font until the text fits on one line (never below min_size)."""
    while size > min_size and stringWidth(text, font, size) > MAX_TEXT_WIDTH:
        size -= 1
    return size


def _centered(c: canvas.Canvas, y: float, text: str, font: str, size: float, color=NAVY, fit=True):
    if fit:
        size = _fit_font_size(text, font, size)
    c.setFont(font, size)
    c.setFillColor(color)
    c.drawCentredString(PAGE_WIDTH / 2, y, text)


def _draw_template(
    c: canvas.Canvas,
    *,
    recipient_name: str,
    event_name: str,
    issued_by: str | None,
    issue_date: date,
    certificate_id: str,
) -> None:
    # Double border
    c.setStrokeColor(GOLD)
    c.setLineWidth(4)
    c.rect(28, 28, PAGE_WIDTH - 56, PAGE_HEIGHT - 56)
    c.setLineWidth(1)
    c.rect(38, 38, PAGE_WIDTH - 76, PAGE_HEIGHT - 76)

    _centered(c, PAGE_HEIGHT - 120, "CERTIFICATE", "Helvetica-Bold", 46, NAVY)
    _centered(c, PAGE_HEIGHT - 150, "OF COMPLETION", "Helvetica", 18, GOLD)

    _centered(c, PAGE_HEIGHT - 215, "This is to certify that", "Helvetica-Oblique", 16, GREY)
    _centered(c, PAGE_HEIGHT - 275, recipient_name, "Helvetica-Bold", 36, NAVY)

    # Underline below the name
    c.setStrokeColor(GOLD)
    c.setLineWidth(1.5)
    c.line(PAGE_WIDTH / 2 - 220, PAGE_HEIGHT - 290, PAGE_WIDTH / 2 + 220, PAGE_HEIGHT - 290)

    _centered(c, PAGE_HEIGHT - 330, "has successfully completed", "Helvetica-Oblique", 16, GREY)
    _centered(c, PAGE_HEIGHT - 375, event_name, "Helvetica-Bold", 26, NAVY)

    date_text = f"Issued on {issue_date.day} {issue_date:%B %Y}"
    _centered(c, 130, date_text, "Helvetica", 13, GREY)
    if issued_by:
        _centered(c, 105, f"Issued by {issued_by}", "Helvetica-Bold", 13, NAVY)

    _centered(c, 60, f"Certificate ID: {certificate_id}", "Helvetica", 9, GREY, fit=False)


def generate_certificate_pdf(
    output_path: Path,
    *,
    recipient_name: str,
    event_name: str,
    issued_by: str | None,
    issue_date: date,
    certificate_id: str,
) -> None:
    """Render one certificate to ``output_path``.

    The PDF is written to a temporary file first and renamed on success, so a
    failure part-way never leaves a corrupt or half-written certificate behind.
    """
    output_path = Path(output_path)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    tmp_path = output_path.with_name(output_path.name + ".tmp")
    try:
        c = canvas.Canvas(str(tmp_path), pagesize=landscape(A4))
        c.setTitle(f"Certificate - {recipient_name}")
        c.setAuthor(issued_by or "Certificate Generator")
        _draw_template(
            c,
            recipient_name=recipient_name,
            event_name=event_name,
            issued_by=issued_by,
            issue_date=issue_date,
            certificate_id=certificate_id,
        )
        c.showPage()
        c.save()
        os.replace(tmp_path, output_path)
    except Exception:
        tmp_path.unlink(missing_ok=True)
        raise
