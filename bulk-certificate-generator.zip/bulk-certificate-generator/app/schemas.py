"""Request and response schemas."""

from datetime import date, datetime
from typing import Annotated, Any, Literal, Optional

from pydantic import BaseModel, ConfigDict, Field, StringConstraints

EventName = Annotated[str, StringConstraints(strip_whitespace=True, min_length=1, max_length=120)]
IssuerName = Annotated[str, StringConstraints(strip_whitespace=True, min_length=1, max_length=80)]


class RecipientIn(BaseModel):
    """A recipient exactly as submitted.

    Fields are deliberately loose (``Any``): a wrong type for ONE recipient
    must not reject the whole request. Each recipient is validated separately
    (see services/validation.py) and failures are reported per recipient.
    """

    model_config = ConfigDict(extra="ignore")

    name: Any = None
    email: Any = None


class JobCreate(BaseModel):
    event_name: EventName = Field(description="Course or event the certificates are for")
    issued_by: Optional[IssuerName] = Field(default=None, description="Issuing organisation")
    issue_date: Optional[date] = Field(default=None, description="Defaults to today")
    recipients: list[RecipientIn] = Field(min_length=1, description="One entry per certificate")


class JobOut(BaseModel):
    id: str
    status: str
    event_name: str
    issued_by: Optional[str]
    issue_date: date
    total: int
    generated: int
    failed: int
    pending: int
    progress_percent: float
    created_at: datetime
    started_at: Optional[datetime]
    finished_at: Optional[datetime]
    certificates_url: str
    download_url: Optional[str] = Field(description="ZIP of all generated certificates; set once the job is finished")


class CertificateOut(BaseModel):
    id: int
    index: int = Field(description="0-based position in the submitted recipients list")
    recipient_name: str
    recipient_email: Optional[str]
    status: str
    error: Optional[str]
    generated_at: Optional[datetime]
    download_url: Optional[str]


class CertificateListOut(BaseModel):
    total: int
    limit: int
    offset: int
    items: list[CertificateOut]


CertificateStatusFilter = Literal["pending", "generated", "failed"]
