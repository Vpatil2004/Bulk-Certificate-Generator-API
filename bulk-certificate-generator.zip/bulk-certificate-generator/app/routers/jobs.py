"""HTTP endpoints for certificate jobs."""

import io
import re
import unicodedata
import zipfile
from datetime import date

from fastapi import APIRouter, BackgroundTasks, Depends, HTTPException, Query
from fastapi.responses import FileResponse, Response
from sqlalchemy import func, select
from sqlalchemy.orm import Session, sessionmaker

from app.config import Settings, get_settings
from app.dependencies import get_db, get_session_factory
from app.models import Certificate, CertificateStatus, Job, JobStatus, utcnow
from app.schemas import (
    CertificateListOut,
    CertificateOut,
    CertificateStatusFilter,
    JobCreate,
    JobOut,
)
from app.services.processor import count_by_status, finalize_job, process_job
from app.services.validation import validate_recipient

router = APIRouter(prefix="/jobs", tags=["jobs"])


# --------------------------------------------------------------------------
# helpers
# --------------------------------------------------------------------------
def _get_job_or_404(db: Session, job_id: str) -> Job:
    job = db.get(Job, job_id)
    if job is None:
        raise HTTPException(status_code=404, detail="Job not found")
    return job


def _job_out(db: Session, job: Job) -> JobOut:
    counts = count_by_status(db, job.id)
    generated = counts[CertificateStatus.GENERATED]
    failed = counts[CertificateStatus.FAILED]
    done = generated + failed
    finished = job.status in JobStatus.FINISHED
    return JobOut(
        id=job.id,
        status=job.status,
        event_name=job.event_name,
        issued_by=job.issued_by,
        issue_date=job.issue_date,
        total=job.total,
        generated=generated,
        failed=failed,
        pending=counts[CertificateStatus.PENDING],
        progress_percent=round(100 * done / job.total, 1) if job.total else 100.0,
        created_at=job.created_at,
        started_at=job.started_at,
        finished_at=job.finished_at,
        certificates_url=f"/jobs/{job.id}/certificates",
        download_url=f"/jobs/{job.id}/download" if finished and generated else None,
    )


def _certificate_out(cert: Certificate) -> CertificateOut:
    generated = cert.status == CertificateStatus.GENERATED
    return CertificateOut(
        id=cert.id,
        index=cert.index,
        recipient_name=cert.recipient_name,
        recipient_email=cert.recipient_email,
        status=cert.status,
        error=cert.error,
        generated_at=cert.generated_at,
        download_url=f"/jobs/{cert.job_id}/certificates/{cert.id}/download" if generated else None,
    )


def _slug(name: str) -> str:
    """File-name-safe version of a name: 'Zoë Müller' -> 'zoe-muller'."""
    ascii_name = unicodedata.normalize("NFKD", name).encode("ascii", "ignore").decode()
    return re.sub(r"[^A-Za-z0-9]+", "-", ascii_name).strip("-").lower() or "recipient"


# --------------------------------------------------------------------------
# endpoints
# --------------------------------------------------------------------------
@router.post("", response_model=JobOut, status_code=202, summary="Submit a bulk certificate request")
def create_job(
    payload: JobCreate,
    background_tasks: BackgroundTasks,
    db: Session = Depends(get_db),
    settings: Settings = Depends(get_settings),
    session_factory: sessionmaker = Depends(get_session_factory),
):
    """Accepts many recipients in ONE request.

    Request-level problems (no recipients, too many, missing event name) are
    rejected with 422. Recipients that are individually invalid are stored as
    failed certificates with an error message; the valid ones are generated in
    the background. Poll `GET /jobs/{id}` for progress.
    """
    if len(payload.recipients) > settings.max_recipients:
        raise HTTPException(
            status_code=422,
            detail=f"Too many recipients: {len(payload.recipients)} (maximum is {settings.max_recipients} per request)",
        )

    job = Job(
        status=JobStatus.PENDING,
        event_name=payload.event_name,
        issued_by=payload.issued_by,
        issue_date=payload.issue_date or date.today(),
        total=len(payload.recipients),
    )
    db.add(job)

    valid_count = 0
    for index, recipient in enumerate(payload.recipients):
        checked = validate_recipient(recipient.name, recipient.email)
        if checked.error:
            status = CertificateStatus.FAILED
        else:
            status = CertificateStatus.PENDING
            valid_count += 1
        job.certificates.append(
            Certificate(
                index=index,
                recipient_name=checked.name,
                recipient_email=checked.email,
                status=status,
                error=checked.error,
            )
        )
    db.commit()

    if valid_count:
        background_tasks.add_task(process_job, job.id, session_factory, settings.cert_dir)
    else:
        # Nothing to generate: finish immediately instead of scheduling work.
        job.started_at = utcnow()
        finalize_job(db, job)

    return _job_out(db, job)


@router.get("/{job_id}", response_model=JobOut, summary="Job status and progress")
def get_job(job_id: str, db: Session = Depends(get_db)):
    return _job_out(db, _get_job_or_404(db, job_id))


@router.get(
    "/{job_id}/certificates",
    response_model=CertificateListOut,
    summary="Per-certificate results (use status=failed to see errors)",
)
def list_certificates(
    job_id: str,
    status: CertificateStatusFilter | None = None,
    limit: int = Query(100, ge=1, le=1000),
    offset: int = Query(0, ge=0),
    db: Session = Depends(get_db),
):
    _get_job_or_404(db, job_id)
    query = select(Certificate).where(Certificate.job_id == job_id)
    if status:
        query = query.where(Certificate.status == status)
    total = db.scalar(select(func.count()).select_from(query.subquery()))
    items = db.scalars(query.order_by(Certificate.index).limit(limit).offset(offset)).all()
    return CertificateListOut(
        total=total, limit=limit, offset=offset, items=[_certificate_out(c) for c in items]
    )


@router.get(
    "/{job_id}/certificates/{certificate_id}/download",
    summary="Download one certificate (PDF)",
    response_class=FileResponse,
)
def download_certificate(
    job_id: str,
    certificate_id: int,
    db: Session = Depends(get_db),
    settings: Settings = Depends(get_settings),
):
    _get_job_or_404(db, job_id)
    cert = db.get(Certificate, certificate_id)
    if cert is None or cert.job_id != job_id:
        raise HTTPException(status_code=404, detail="Certificate not found")
    if cert.status != CertificateStatus.GENERATED:
        raise HTTPException(
            status_code=409, detail=f"Certificate is not available (status: {cert.status})"
        )
    path = settings.cert_dir / cert.file_path
    if not path.is_file():
        raise HTTPException(status_code=404, detail="Certificate file is missing on the server")
    return FileResponse(
        path,
        media_type="application/pdf",
        filename=f"certificate-{_slug(cert.recipient_name)}-{cert.id}.pdf",
    )


@router.get("/{job_id}/download", summary="Download all generated certificates (ZIP)")
def download_job_zip(
    job_id: str,
    db: Session = Depends(get_db),
    settings: Settings = Depends(get_settings),
):
    job = _get_job_or_404(db, job_id)
    if job.status not in JobStatus.FINISHED:
        raise HTTPException(status_code=409, detail=f"Job is still {job.status}; try again when it has finished")

    certs = db.scalars(
        select(Certificate)
        .where(Certificate.job_id == job_id, Certificate.status == CertificateStatus.GENERATED)
        .order_by(Certificate.index)
    ).all()
    if not certs:
        raise HTTPException(status_code=404, detail="No certificates were generated for this job")

    buffer = io.BytesIO()
    with zipfile.ZipFile(buffer, "w", zipfile.ZIP_DEFLATED) as archive:
        for cert in certs:
            path = settings.cert_dir / cert.file_path
            if path.is_file():
                # Row number keeps names unique even when two recipients share a name.
                archive.write(path, arcname=f"{cert.index + 1:04d}-{_slug(cert.recipient_name)}.pdf")
    return Response(
        content=buffer.getvalue(),
        media_type="application/zip",
        headers={"Content-Disposition": f'attachment; filename="certificates-{job_id[:8]}.zip"'},
    )
