"""Write a large sample request to stdout, e.g. for trying out bulk generation.

    python examples/make_large_request.py 500 > big.json
    curl -X POST localhost:8000/jobs -H "Content-Type: application/json" -d @big.json
"""

import json
import sys

count = int(sys.argv[1]) if len(sys.argv) > 1 else 200
payload = {
    "event_name": "Load Test Workshop",
    "issued_by": "Aereo Academy",
    "recipients": [
        {"name": f"Participant {i:04d}", "email": f"participant{i}@example.com"}
        for i in range(1, count + 1)
    ],
}
print(json.dumps(payload))
